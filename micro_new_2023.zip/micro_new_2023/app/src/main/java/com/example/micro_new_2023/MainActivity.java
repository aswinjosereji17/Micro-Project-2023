package com.example.micro_new_2023;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_nxt= (Button) findViewById(R.id.login);
      EditText i1=(EditText) findViewById(R.id.username);
      EditText i2=(EditText) findViewById(R.id.pass);
        db=openOrCreateDatabase("login", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS login(user VARCHAR,pass VARCHAR);");

        btn_nxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(i1.getText().toString().equals("admin") && i2.getText().toString().equals("admin")){


                    Intent in= new Intent(MainActivity.this,home.class);
                    startActivity(in);
                }
               else{
                   AlertDialog.Builder wrong=new AlertDialog.Builder(MainActivity.this);
                   wrong.setTitle("Incorrect username and password");
                   wrong.setPositiveButton("Ok",null);
                   wrong.setCancelable(true);
                   wrong.create().show();
               }
               clearText();
            }
            public void clearText()
            {
                i1.setText("");
                i2.setText("");
            }

        });
    }
}






