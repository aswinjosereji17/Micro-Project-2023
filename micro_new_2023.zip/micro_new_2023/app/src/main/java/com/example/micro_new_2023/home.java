package com.example.micro_new_2023;

import android.app.AlertDialog;
import android.os.Bundle;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;


public class home extends Activity implements android.view.View.OnClickListener
{
    EditText qid,ques,ans;
    RadioGroup rg;
    RadioButton r;
    Button Add,Delete,Search,ViewAll;
    Spinner cat;
    SQLiteDatabase db;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        qid=(EditText)findViewById(R.id.qid);
        ques=(EditText)findViewById(R.id.ques);
        ans=(EditText)findViewById(R.id.ans);

        Add=(Button)findViewById(R.id.Add);
        Delete=(Button)findViewById(R.id.Delete);
        Search=(Button)findViewById(R.id.Search);
        ViewAll=(Button)findViewById(R.id.ViewAll);

        rg=(RadioGroup) findViewById(R.id.rg);

        Add.setOnClickListener(this);
        Delete.setOnClickListener(this);
        Search.setOnClickListener(this);
        ViewAll.setOnClickListener(this);

        String[] courses = {"Chain Rule","Area","Clock"};
        ArrayAdapter<String> courseAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,courses);
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cat = (Spinner) findViewById(R.id.spinner);
        cat.setAdapter(courseAdapter);

        db=openOrCreateDatabase("aptitudedb", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS aptitudedb(rowid INTEGER PRIMARY KEY AUTOINCREMENT,ques VARCHAR,ans VARCHAR,cat VARCHAR);");
    }
    public void onClick(View view)
    {

        if(view==Add)
        {

            String course = (cat.getSelectedItem().toString());

            if(
                    ques.getText().toString().trim().length()==0||
                            ans.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter all values");
                return;
            }
            db.execSQL("INSERT INTO aptitudedb(ques,ans,cat) VALUES('"+ques.getText().toString()+
                    "','"+ans.getText().toString()+"','"+course.toString()+"');");
            showMessage("Success","Inserted");
            clearText();
        }
        // Deleting a record from the Student table
        if(view==Delete)
        {
            // Checking for empty roll number
            if(qid.getText().toString().trim().length()==0)
            {
                showMessage("Error", "Please enter Rollno");
                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM aptitudedb WHERE rowid='"+qid.getText()+"'", null);
            if(c.moveToFirst())
            {
                db.execSQL("DELETE FROM aptitudedb WHERE rowid='"+qid.getText()+"'");
                showMessage("Success", "Data Deleted");
            }
            else
            {
                showMessage("Error", "Invalid Question id");
            }
            clearText();
        }

        if(view==Search)
        {

            int idr=rg.getCheckedRadioButtonId();
            r=(RadioButton) findViewById(idr);
            String val=(String)r.getText();
            if(val==""){
                showMessage("Error", "Data not found");
                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM aptitudedb WHERE cat='"+r.getText()+"'", null);

            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Id : "+c.getString(0)+"\n");
                buffer.append("Question : "+c.getString(1)+"\n");
                buffer.append("Answer  : "+c.getString(2)+"\n\n");
            }
            showMessage("               " +r.getText().toString() +" Questions", buffer.toString());


        }
        if(view==ViewAll)
        {
            Cursor c=db.rawQuery("SELECT * FROM aptitudedb", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "Data not found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("Id : "+c.getString(0)+"\n");
                buffer.append("Question : "+c.getString(1)+"\n");
                buffer.append("Answer  : "+c.getString(2)+"\n\n");
            }
            showMessage("           Aptitude Questions", buffer.toString());
        }
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        ques.setText("");
        ans.setText("");
        qid.setText("");
    }
}

